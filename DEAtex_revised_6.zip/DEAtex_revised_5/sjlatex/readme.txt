NOTE:  readme.txt template -- do not remove empty entries, but you may
                              add entries for additional authors
------------------------------------------------------------------------------

Package name:   <leave blank>

Title:  

Author 1 name: 
Author 1 from:  
Author 1 email: 

Author 2 name:  
Author 2 from:  
Author 2 email: 

Author 3 name:  
Author 3 from:  
Author 3 email: 

Author 4 name:  
Author 4 from:  
Author 4 email: 

Author 5 name:  
Author 5 from:  
Author 5 email: 

Help keywords: 

File list: 

Notes:

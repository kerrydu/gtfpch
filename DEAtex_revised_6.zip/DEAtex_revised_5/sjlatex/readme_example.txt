NOTE:  This is an example "readme.txt" file that goes with a Stata Journal
            software submission. 
------------------------------------------------------------------------------

Package name:  Article tag (Stata Press to add)

Title:  Title of your article

Author 1 name:  First author name
Author 1 from:  First author affiliation, city, state/country
                    Include all information on one line with commas separating
                    the information, for example, 
                Nicholas J. Cox, Department of Geography, Durham University, Durham, UK
Author 1 email: First author email address

Author 2 name:  Second author name
Author 2 from:  Second author affiliation
Author 2 email: Second author email address

Author 3 name:  Third author name
Author 3 from:  Third author affiliation
Author 3 email: Third author email address

Author 4 name:  Fourth author name
Author 4 from:  Fourth author affiliation
Author 4 email: Fourth author email address

Author 5 name:  Fifth author name
Author 5 from:  Fifth author affiliation
Author 5 email: Fifth author email address

Help keywords:  Name of help files listed on one line with one blank space 
                    separating the information. For multiple name help files,
                    place the name in double quotes, for example,
                regress "regress postestimation" "regress postestimation diagnostic plots" "regress postestimation ts"

File list: Filenames to include in the package listed on one line with
               one blank space separating the information.  For example,
           myprog1.ado myprog1.hlp myprog2.ado myprog2.hlp example1.do data1.dta example2.do

Notes: Special notes, for example, if another user-written software package is
          required or if a dataset has been included for testing purposes only.
